#21 53
import flask
from flask import Flask, request, jsonify, abort, redirect, url_for, render_template, send_file,redirect,Response
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import io
import random
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
from pylab import *
from budget import *
import os
from werkzeug.utils import secure_filename
from flask_wtf import FlaskForm
from wtforms import StringField, FileField
from wtforms.validators import DataRequired
from bokeh.io import output_file
from bokeh.plotting import figure, show

app = Flask(__name__)


@app.route('/')
def hello_world():
    return render_template("first.html")


@app.route('/about')
def about():
    return render_template("about.html")

@app.route('/result')
def info():
    return render_template("result.html")

app.config.update(dict(
    SECRET_KEY="powerful secretkey",
    WTF_CSRF_SECRET_KEY="a csrf secret key"
))


class MyForm(FlaskForm):
    name = StringField('name', validators=[DataRequired()])
    file = FileField()

def build_model():
    try:
        X = pd.read_csv('features.csv', index_col=0)
        y = pd.read_csv('target.csv', index_col=0)
        print('All of the data has been loaded successfully!')
    except Exception as err:
        print(repr(err))
    print()

    tmp = BudgetModel(X, y)
    tmp.train()
    predicts = tmp.predict()
    for i, p in enumerate(predicts):
        print(i)
        p.to_csv('predict', index=False)
    return predicts


@app.route('/upload', methods=('GET', 'POST'))
def upload():
    if request.method == "POST":
        uploaded_files = flask.request.files.getlist("file[]")
        print (uploaded_files)
        #check that files are read
        for f in uploaded_files:
            df = pd.read_excel(f, index_col=0)
            print(df.head())
        #for example lets assume we got correct input
        predict = build_model()
        filename = 'predict'
        return send_file(filename,
                     mimetype='text/csv',
                     attachment_filename=filename,
                     as_attachment=True)
        print(predict)


        '''
            predict = knn.predict(df)
    
            result = pd.DataFrame(predict)
            result.to_csv(filename, index=False)
    
            return send_file(filename,
                             mimetype='text/csv',
                             attachment_filename=filename,
                             as_attachment=True)
        '''
    else:
        return render_template('upload.html')



'''
@app.route('/boke')
def hw():
    plt.style.use('ggplot')

    mn, mx, N = -10000, 10000, 1000
    dataset = pd.Series(data=[i for i in range(1000)],
                        name='X')

    plt.subplot(2, 2, 1)
    plt.plot(list(range(1000)), dataset, alpha=0.8)
    plt.title("Линейный график")

    plt.subplot(2, 2, 3)
    plt.hist(dataset, alpha=0.8)  # plot (xlist, ylist)
    plt.title("Гистограмма значений")

    dataframe = pd.DataFrame(dataset)
    dataframe['X_по_возрастанию'] = dataframe.X.sort_values().values
    dataframe['X_по_убыванию'] = dataframe.X.sort_values(ascending=False).values
    dataframe.head()

    # Две строки, два столбца. Текущая ячейка - 2
    plt.subplot(1, 2, 2)
    plt.plot(dataframe['X_по_возрастанию'], label="X по возрастанию")
    plt.plot(dataframe['X_по_убыванию'], label="X по убыванию")
    plt.title("Два линейных графика")

    plt.show()
    return render_template("first.html")
'''

if __name__ == '__main__':
    app.run()